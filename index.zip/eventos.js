function cambiarTitulo() {
    document.getElementById("titulo").innerText = "¡Markus - Líder de la revolución!";
}

function resaltarTexto() {
    document.getElementById("frase1").style.color = "#00c8ff";
}

function quitarResaltado() {
    document.getElementById("frase1").style.color = "#cccccc";
}

function agrandarImagen() {
    document.getElementById("imgMarkus").style.width = "300px";
}

function bienvenida() {
    alert("Bienvenido a la pagina de Markus");
}

function llamarMiPagina1() {
    window.location.href = "pagina1.html";
}